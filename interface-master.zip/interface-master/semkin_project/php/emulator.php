<?php
// 1. ОБРАБОТКА AJAX ЗАПРОСА
if (isset($_REQUEST['action']) && $_REQUEST['action'] === 'check_emulator_data_ajax') {
    
    // Получаем сырые данные
    $rawFio = getRawFIOFromEmulator();
    
    if ($rawFio === false) {
        // Используем классы сообщений из styles_index.css
        echo '<div class="message message-error" style="margin-top: 0;">
                <span class="material-icons">error</span>
                Не удалось получить ответ от эмулятора (Таймаут или ошибка сети).
              </div>';
        exit;
    }

    // Проводим валидацию
    $validationResult = isValidFIO($rawFio);

    // Формируем HTML отчет
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <div class="card" style="margin-top: 1.5rem;">
        <h3 class="form-title" style="margin-bottom: 0.5rem;">
            <span class="material-icons" style="color: var(--primary-color); vertical-align: middle;">sync_alt</span> 
            Результат проверки данных эмулятора
        </h3>
        
        <p style="color: var(--text-secondary); margin-top: 1rem;"><strong>Полученные сырые данные:</strong></p>
        <div class="sql-textarea" style="min-height: auto; font-size: 0.9rem; margin-bottom: 1rem; border: 1px dashed var(--border-color);">
            "<?php echo htmlspecialchars($rawFio); ?>"
        </div>

        <?php if ($validationResult['valid']): ?>
            <div class="message message-success">
                <span class="material-icons">check_circle</span>
                <span style="font-weight: 600;">✅ ВАЛИДАЦИЯ ПРОЙДЕНА</span>
                <p style="margin: 0; padding-left: 0.75rem;">Данные соответствуют строгим внутренним стандартам.</p>
            </div>
        <?php else: ?>
            <div class="message message-error">
                <span class="material-icons">cancel</span>
                <span style="font-weight: 600;">❌ ВАЛИДАЦИЯ НЕ ПРОЙДЕНА</span>
            </div>
            <p style="margin-top: 10px; color: var(--danger-color);">Обнаружены следующие **конкретные** причины ошибок:</p>
            <ul style="padding-left: 25px; color: var(--text-primary);">
                <?php foreach ($validationResult['errors'] as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <div class="info-panel" style="margin-top: 1.5rem; padding: 1rem; border-left: 4px solid var(--primary-color);">
            <p class="info-text" style="margin-bottom: 0; color: var(--text-secondary);">
                <span style="font-weight: bold; color: var(--text-primary);">Важно:</span> Данные были проверены "как есть" без какой-либо предварительной обработки (очистки, нормализации).
            </p>
        </div>
    </div>
    <?php
    exit;
}

// 2. ФУНКЦИИ ЛОГИКИ (БИЗНЕС-СЛОЙ)
function getRawFIOFromEmulator() {
    $url = 'http://prb.sylas.ru/TransferSimulator/fullName';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($response === false || $httpCode !== 200) {
        return false;
    }
    $data = json_decode($response, true);
    if (json_last_error() === JSON_ERROR_NONE && isset($data['value'])) {
        return $data['value'];
    }
    return false;
}

function isValidFIO($fio) {
    $errors = [];
    $length = mb_strlen($fio, 'UTF-8');
    if ($length < 5 || $length > 100) {
        $errors[] = "Недопустимая общая длина строки ($length). Ожидается от 5 до 100 символов.";
    }
    if (preg_match('/[^а-яА-ЯёЁ\s\-]/u', $fio)) {
        $errors[] = "Присутствуют недопустимые символы (латиница, цифры, спецсимволы). Разрешена только кириллица, пробел и дефис.";
    }
    $words = preg_split('/\s+/u', trim($fio), -1, PREG_SPLIT_NO_EMPTY);
    if (count($words) !== 3) {
        $errors[] = "ФИО должно состоять ровно из 3 слов. Найдено: " . count($words) . ".";
    } else {
        foreach ($words as $index => $word) {
            $wordNum = $index + 1;
            if (mb_strlen($word, 'UTF-8') < 2) {
                $errors[] = "Слово №$wordNum («" . htmlspecialchars($word) . "») слишком короткое. Минимум 2 символа.";
            }
            $firstChar = mb_substr($word, 0, 1, 'UTF-8');
            if ($firstChar !== mb_strtoupper($firstChar, 'UTF-8')) {
                $errors[] = "Слово №$wordNum («" . htmlspecialchars($word) . "») должно начинаться с заглавной буквы.";
            }
            if (mb_strpos($word, '-', 0, 'UTF-8') === 0 || mb_substr($word, -1, 1, 'UTF-8') === '-') {
                $errors[] = "Слово №$wordNum содержит дефис в начале или в конце слова (разрешено только внутри).";
            }
        }
    }
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}

// 3. HTML СТРАНИЦА (САЙТБАР, ХЕДЕР, КОНТЕНТ)
session_start();

// Проверка авторизации (предполагаем наличие)
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // header('Location: login.php');
    // exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Проверка эмулятора | Панель админа</title>
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/styles_index.css">
</head>

<body>
    <header class="header">
        <div class="logo">
            <span class="material-icons" style="font-size: 2rem; color: var(--primary-color);">restaurant</span>
            Панель админа
        </div>
        
        <div class="header-actions">
            <a href="performance.php" class="btn btn-icon" title="Мониторинг">
                <span class="material-icons">speed</span>
            </a>
            <button class="btn btn-icon" onclick="toggleTheme()" title="Переключить тему">
                <span class="material-icons" id="themeIcon">dark_mode</span>
            </button>
            <button class="btn btn-secondary" onclick="showLogoutModal()">
                <span class="material-icons">logout</span>
                Выход
            </button>
        </div>
    </header>

    <main class="main-content">
        <aside class="sidebar">
            <h3 class="nav-title">Управление</h3>
            <nav class="nav-list">
                <a href="chef.php" class="nav-link">
                    <span class="material-icons">person</span>
                    Шеф-повара
                </a>
                <a href="dishes.php" class="nav-link">
                    <span class="material-icons">local_dining</span>
                    Блюда
                </a>
                <a href="ingredients.php" class="nav-link">
                    <span class="material-icons">kitchen</span>
                    Ингредиенты
                </a>
                <a href="orders.php" class="nav-link">
                    <span class="material-icons">shopping_cart</span>
                    Заказы
                </a>
                <a href="recipes.php" class="nav-link">
                    <span class="material-icons">menu_book</span>
                    Рецепты
                </a>
            </nav>

            <h3 class="nav-title" style="margin-top: 2rem;">Система</h3>
            <nav class="nav-list">
                <a href="#" class="nav-link" onclick="launchRemmina(); return false;">
                    <span class="material-icons">desktop_windows</span>
                    VNC Подключение
                </a>
                <a href="#" class="nav-link" onclick="showAddUserModal(); return false;">
                    <span class="material-icons">person_add</span>
                    Добавить пользователя
                </a>
                <a href="#" class="nav-link" onclick="showDeleteUserModal(); return false;">
                    <span class="material-icons">person_remove</span>
                    Удалить пользователя
                </a>
                <a href="unlock_admin.php" class="nav-link" target="_blank">
                    <span class="material-icons">security</span>
                    Разблокировать пользователей
                </a>
                <a href="#" class="nav-link" onclick="showSqlConsoleModal(); return false;">
                    <span class="material-icons">code</span>
                    SQL Консоль
                </a>
                <a href="emulator.php" class="nav-link active">
                    <span class="material-icons">cloud_sync</span>
                    Проверка эмулятора ФИО
                </a>
            </nav>
        </aside>

        <div class="content">
            <div class="page-header">
                <h1 class="page-title">🔬 Мониторинг качества данных (Эмулятор)</h1>
                <a href="index.php" class="btn btn-secondary" title="На главную">
                    <span class="material-icons">arrow_back</span> Назад
                </a>
            </div>

            <div class="info-panel">
                <p class="info-text">Нажмите кнопку ниже, чтобы запросить случайное ФИО от внешнего сервиса и проверить его на соответствие строгим внутренним правилам валидации.</p>
            </div>
            
            <div class="card form-section" style="margin-top: 1.5rem;">
                <h2 class="form-title">Запуск проверки</h2>
                
                <button class="btn btn-primary" onclick="checkEmulator()">
                    <span class="material-icons">sync</span>
                    Проверить данные эмулятора
                </button>

                <div id="loader" class="loader" style="display: none; color: var(--primary-color); margin-top: 1rem; font-weight: 500;">
                    <span class="material-icons" style="vertical-align: middle;">hourglass_empty</span>
                    Запрос к эмулятору (ожидание ответа)...
                </div>

                <div id="emulator-results">
                    </div>
            </div>
        </div>
    </main>

    <div id="logoutModal" class="modal modal-danger">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-icon">
                    <span class="material-icons">logout</span>
                </div>
                <h3 class="modal-title">Подтверждение выхода</h3>
            </div>
            <p class="modal-description">
                Вы действительно хотите выйти из системы? Ваша текущая сессия будет завершена.
            </p>
            <div class="modal-actions">
                <button class="btn-modal btn-cancel" onclick="closeModal('logoutModal')">Отмена</button>
                <a href="index.php?action=logout&confirm=yes" class="btn-modal btn-confirm" style="text-align: center; text-decoration: none; line-height: 1.5;">Выйти</a>
            </div>
        </div>
    </div>
    
    <script>
        function checkEmulator() {
            const resultsDiv = document.getElementById('emulator-results');
            const loader = document.getElementById('loader');

            resultsDiv.innerHTML = '';
            loader.style.display = 'flex'; // Используем flex для красивого отображения лоадера

            fetch('emulator.php?action=check_emulator_data_ajax')
                .then(response => response.text())
                .then(html => {
                    loader.style.display = 'none';
                    resultsDiv.innerHTML = html;
                })
                .catch(error => {
                    loader.style.display = 'none';
                    resultsDiv.innerHTML = `
                        <div class="message message-error" style="margin-top: 1rem;">
                            <span class="material-icons">error</span>
                            Ошибка выполнения запроса. Проверьте консоль.
                        </div>`;
                    console.error('Error:', error);
                });
        }
        
        // Функции для работы темы и модалок (если scripts_index.js не подключен или пуст)
        // Если у вас есть scripts_index.js, этот код можно убрать, оставив только checkEmulator.
        function toggleTheme() {
            const body = document.body;
            const currentTheme = body.getAttribute('data-theme');
            const icon = document.getElementById('themeIcon');
            
            if (currentTheme === 'dark') {
                body.removeAttribute('data-theme');
                icon.textContent = 'dark_mode';
                localStorage.setItem('theme', 'light');
            } else {
                body.setAttribute('data-theme', 'dark');
                icon.textContent = 'light_mode';
                localStorage.setItem('theme', 'dark');
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.setAttribute('data-theme', 'dark');
                document.getElementById('themeIcon').textContent = 'light_mode';
            }
        });

        function showLogoutModal() {
            document.getElementById('logoutModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>