<?php

session_start();

require_once 'db_connect.php';

// FIXED: Обработка принятия условий (AJAX от JS)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accepted_terms'])) {
    $_SESSION['accepted_terms'] = true;
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// Генерация CSRF токена для защиты
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Проверка, если пользователь согласился с условиями
if (!isset($_SESSION['accepted_terms'])) {
    $_SESSION['accepted_terms'] = false;
}

// Инициализация капчи
if (!isset($_SESSION['captcha_attempts'])) {
    $_SESSION['captcha_attempts'] = 0;
}

if (!isset($_SESSION['captcha_solved'])) {
    $_SESSION['captcha_solved'] = false;
}

// Генерация случайного порядка фрагментов для капчи
// FIXED: Убрали ненужное условие с verifyCaptcha, т.к. shuffle только на fail в AJAX
if (!isset($_SESSION['captcha_order'])) {
    $_SESSION['captcha_order'] = range(1, 4);
    shuffle($_SESSION['captcha_order']);
}

// Обработка AJAX-запроса для капчи
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_data']) && !isset($_POST['username'])) {
    $captcha_result = verifyCaptcha($_POST['captcha_data']);
    header('Content-Type: application/json');
    if ($captcha_result === true) {
        $_SESSION['captcha_solved'] = true;
        $_SESSION['captcha_attempts'] = 0;
        echo json_encode(['success' => true]);
    } else {
        $_SESSION['captcha_attempts']++;
        $remaining_attempts = 3 - $_SESSION['captcha_attempts'];
        $_SESSION['captcha_order'] = range(1, 4);
        shuffle($_SESSION['captcha_order']);
        if ($_SESSION['captcha_attempts'] >= 3) {
            // FIXED: Убрали blockAccount (нет username). Изменили сообщение
            echo json_encode(['success' => false, 'error' => 'Капча не пройдена 3 раза подряд. Слишком много попыток, пожалуйста, обновите страницу или попробуйте позже.']);
        } else {
            echo json_encode(['success' => false, 'error' => "Неправильно собран пазл! Осталось попыток: {$remaining_attempts}"]);
        }
    }
    exit;
}

// Проверка при отправке формы логина
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Проверка CSRF токена
    if ($csrf_token !== $_SESSION['csrf_token']) {
        $error = 'Ошибка: Неверный CSRF токен';
    } elseif (!$_SESSION['captcha_solved']) {
        $error = 'Пожалуйста, сначала пройдите капчу';
    } else {
        $login_result = verifyAdminLogin($conn, $username, $password);
        
        if ($login_result === true) {
            $admin = getAdminByUsername($conn, $username);
            $_SESSION['logged_in'] = true;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $admin['role'] ?? 'User';
            $_SESSION['captcha_solved'] = false; // Сбрасываем капчу только после успешного логина
            $_SESSION['captcha_attempts'] = 0;
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header('Location: index.php');
            exit;
        } elseif (is_array($login_result) && isset($login_result['blocked'])) {
            $error = isset($login_result['unlock_time'])
                ? "Аккаунт заблокирован до " . (new DateTime($login_result['unlock_time']))->format('d.m.Y H:i:s') . ". Попробуйте позже."
                : "Аккаунт заблокирован после 3 неудачных попыток. Обратитесь к администратору.";
        } else {
            $status = getAccountStatus($conn, $username);
            if ($status && !$status['is_locked']) {
                $error = "Неверный логин или пароль! Осталось попыток: " . (3 - $status['failed_attempts']);
            } else {
                $error = "Неверный логин или пароль!";
            }
        }
    }
}

// Функция проверки капчи
function verifyCaptcha($captcha_data) {
    if (empty($captcha_data)) {
        return false;
    }
    
    $positions = json_decode($captcha_data, true);
    if (!is_array($positions) || count($positions) !== 4) {
        return false;
    }
    
    // Проверяем, что нет незаполненных слотов
    if (in_array(0, $positions)) {
        return false;
    }
    
    // Проверяем правильный порядок (1,2,3,4)
    $correct_order = [1, 2, 3, 4];
    foreach ($positions as $index => $fragment_id) {
        if ($fragment_id != $correct_order[$index]) {
            return false;
        }
    }
    
    return true;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в систему | Панель админа</title>
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/styles_login.css">
    <script src="js/scripts_login.js" defer></script>
</head>

<body data-theme="light">
    <button class="theme-toggle" onclick="toggleTheme()" title="Переключить тему" aria-label="Переключить тему">
        <span class="material-icons" id="themeIcon">dark_mode</span>
    </button>

    <div class="page-container">
        <div class="login-card" id="loginCard">
            <div class="login-header">
                <div class="login-logo">
                    <span class="material-icons">lock</span>
                </div>
                <h1 class="login-title">Добро пожаловать</h1>
                <p class="login-subtitle">Войдите в панель администратора</p>
            </div>

            <?php if (isset($error) && $_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                <div class="message message-error">
                    <span class="material-icons">error</span>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="login-form" id="loginForm">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <input type="hidden" name="captcha_data" id="captchaData" value="">
                
                <div class="form-group">
                    <label class="form-label" for="username">Логин</label>
                    <div class="input-wrapper">
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            class="form-input" 
                            placeholder="Введите логин" 
                            required 
                            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                            autocomplete="username"
                            aria-describedby="username-help"
                            <?= $_SESSION['captcha_solved'] ? '' : 'disabled' ?>
                        >
                        <span class="input-icon material-icons">person</span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Пароль</label>
                    <div class="input-wrapper">
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="Введите пароль" 
                            required 
                            autocomplete="current-password"
                            aria-describedby="password-help"
                            <?= $_SESSION['captcha_solved'] ? '' : 'disabled' ?>
                        >
                        <button type="button" class="password-toggle material-icons" onclick="togglePassword()" title="Показать пароль" aria-label="Показать пароль">
                            visibility
                        </button>
                        <span class="input-icon material-icons">lock</span>
                    </div>
                </div>

                <?php if (!$_SESSION['captcha_solved']): ?>
                <div class="captcha-container" id="captchaContainer">
                    <div class="captcha-header">
                        <h3>Соберите пазл для продолжения</h3>
                    </div>
                    <div class="captcha-description">
                        Перетащите фрагменты в правильном порядке
                    </div>
                    <div class="puzzle-container">
                        <div class="puzzle-fragments" id="puzzleFragments">
                            <?php foreach ($_SESSION['captcha_order'] as $fragment_id): ?>
                            <div class="puzzle-fragment" data-fragment="<?= $fragment_id ?>">
                                <img src="img/<?= $fragment_id ?>.png" alt="Фрагмент пазла <?= $fragment_id ?>">
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="puzzle-target" id="puzzleTarget">
                            <div class="target-slot" data-slot="1"><span></span></div>
                            <div class="target-slot" data-slot="2"><span></span></div>
                            <div class="target-slot" data-slot="3"><span></span></div>
                            <div class="target-slot" data-slot="4"><span></span></div>
                        </div>
                    </div>
                    <button type="button" class="btn-captcha" onclick="verifyPuzzle()">
                        <span class="material-icons">check_circle</span>
                        Проверить пазл
                    </button>
                    <button type="button" class="btn-captcha btn-secondary" onclick="resetPuzzle()">
                        <span class="material-icons">refresh</span>
                        Перемешать
                    </button>
                </div>
                <?php else: ?>
                <div class="captcha-success">
                    <span class="material-icons">check_circle</span>
                    Капча успешно пройдена! Теперь вы можете ввести логин и пароль.
                </div>
                <?php endif; ?>

                <button type="submit" class="btn-login" id="loginBtn" <?= $_SESSION['captcha_solved'] ? '' : 'disabled' ?>>
                    <span class="material-icons">login</span>
                    Войти в систему
                </button>  
                <div class="security-info">
                    <div class="security-item">
                        <span class="material-icons">lock</span>
                        После 3 неудачных попыток пазла или пароля аккаунт блокируется
                    </div>
                    <div class="security-item">
                        <span class="material-icons">security</span>
                        Все соединения защищены SSL и CSRF токенами
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div id="termsModal" class="modal <?= $_SESSION['accepted_terms'] ? '' : 'active' ?>">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-icon">
                    <span class="material-icons">gavel</span>
                </div>
                <div>
                    <h3 class="modal-title">Условия использования</h3>
                    <p class="modal-subtitle">Лицензионное соглашение</p>
                </div>
            </div>

            <div class="modal-description">
                <div class="modal-text">
                    <strong>Проект:</strong> Панель администратора для системы управления кухней<br><br>
                    <strong>Разработчики:</strong><br>
                    • Семкин Иван (@nertoff)<br>
                    • Щегольков Максим (@Oxigen4ik)<br><br>
                    <em>Вся документация и программное обеспечение защищены авторским правом 
                    и могут использоваться только с письменного разрешения разработчиков.</em>
                </div>
                
                <div class="contact-info">
                    <strong>Контакты для связи:</strong>
                    📧 35313531as@gmail.com<br>
                    📧 q_bite@mail.ru<br>
                    📱 Telegram: <a href="https://t.me/nertoff" target="_blank">@nertoff</a> (Семкин Иван)<br>
                    📱 Telegram: <a href="https://t.me/Oxigen4ik" target="_blank">@Oxigen4ik</a> (Щегольков Максим)
                </div>
            </div>

            <div class="modal-actions">
                <button class="btn-modal btn-decline" onclick="declineTerms()" aria-label="Отказаться от условий">
                    <span class="material-icons">close</span>
                    Отказаться
                </button>
                <button class="btn-modal btn-accept" onclick="acceptTerms()" aria-label="Принять условия">
                    <span class="material-icons">check</span>
                    Принять и продолжить
                </button>
            </div>
        </div>
    </div>
</body>
</html>