<?php
define('DB_HOST', '134.90.167.42:10306');
define('DB_NAME', 'project_Semkin');
define('DB_USER', 'Semkin');
define('DB_PASS', 'xE-8sT');
?>