const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);
document.getElementById('themeIcon').textContent = savedTheme === 'dark' ? 'light_mode' : 'dark_mode';

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    document.getElementById('themeIcon').textContent = newTheme === 'dark' ? 'light_mode' : 'dark_mode';
}

function togglePassword() {
    const passwordField = document.getElementById('password');
    const toggleBtn = document.querySelector('.password-toggle');
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        toggleBtn.textContent = 'visibility_off';
        toggleBtn.setAttribute('aria-label', 'Скрыть пароль');
    } else {
        passwordField.type = 'password';
        toggleBtn.textContent = 'visibility';
        toggleBtn.setAttribute('aria-label', 'Показать пароль');
    }
}

let draggedFragment = null;

function initializePuzzle() {
    const fragments = document.querySelectorAll('.puzzle-fragment');
    const slots = document.querySelectorAll('.target-slot');
    
    fragments.forEach(fragment => {
        fragment.setAttribute('draggable', 'true');
        
        fragment.addEventListener('dragstart', function(e) {
            draggedFragment = this;
            this.classList.add('dragging');
            e.dataTransfer.setData('text/plain', this.dataset.fragment);
        });
        
        fragment.addEventListener('dragend', function() {
            this.classList.remove('dragging');
            draggedFragment = null;
        });
    });
    
    slots.forEach(slot => {
        slot.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('over');
        });
        
        slot.addEventListener('dragleave', function() {
            this.classList.remove('over');
        });
        
        slot.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('over');
            
            if (draggedFragment && !this.classList.contains('filled')) {
                draggedFragment.remove();
                
                const fragmentCopy = draggedFragment.cloneNode(true);
                fragmentCopy.classList.remove('dragging');
                fragmentCopy.setAttribute('draggable', 'false');
                fragmentCopy.style.cursor = 'default';
                
                this.innerHTML = '';
                this.appendChild(fragmentCopy);
                this.classList.add('filled');
                
                updateCaptchaData();
            }
        });
    });
}

function updateCaptchaData() {
    const slots = Array.from(document.querySelectorAll('.target-slot')).sort((a, b) => 
        parseInt(a.dataset.slot) - parseInt(b.dataset.slot)
    );
    const captchaData = [];
    
    slots.forEach(slot => {
        if (slot.classList.contains('filled')) {
            const fragment = slot.querySelector('.puzzle-fragment');
            if (fragment) {
                captchaData.push(parseInt(fragment.dataset.fragment));
            } else {
                captchaData.push(0);
            }
        } else {
            captchaData.push(0);
        }
    });
    
    document.getElementById('captchaData').value = JSON.stringify(captchaData);
}

function verifyPuzzle() {
    const captchaData = document.getElementById('captchaData').value;
    const usernameField = document.getElementById('username');
    const passwordField = document.getElementById('password');
    const loginBtn = document.getElementById('loginBtn');
    const captchaContainer = document.getElementById('captchaContainer');
    
    if (!captchaData || captchaData === '[0,0,0,0]') {
        showMessage('Пожалуйста, соберите пазл полностью', 'error');
        return;
    }
    
    fetch('', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'captcha_data=' + encodeURIComponent(captchaData)
    }).then(response => response.json()).then(data => {
        if (data.success) {
            usernameField.removeAttribute('disabled');
            passwordField.removeAttribute('disabled');
            loginBtn.removeAttribute('disabled');
            captchaContainer.style.display = 'none';
            showMessage('Капча успешно пройдена!', 'success');
            usernameField.focus();
        } else {
            showMessage(data.error || 'Неправильно собран пазл!', 'error');
            // FIXED: Убрали resetPuzzle() перед reload (бесполезно, т.к. reload берёт новый order из сессии)
            captchaContainer.style.display = 'block';
            setTimeout(() => { location.reload(); }, 2000); // FIXED: Delay reload для показа сообщения
        }
    }).catch(error => {
        console.error('Ошибка при проверке капчи:', error);
        showMessage('Ошибка при проверке капчи', 'error');
        captchaContainer.style.display = 'block';
        setTimeout(() => { location.reload(); }, 2000);
    });
}

function resetPuzzle() {
    const fragmentsContainer = document.getElementById('puzzleFragments');
    const targetContainer = document.getElementById('puzzleTarget');
    
    const fragments = targetContainer.querySelectorAll('.puzzle-fragment');
    fragments.forEach(fragment => {
        fragment.remove();
    });
    
    const slots = targetContainer.querySelectorAll('.target-slot');
    slots.forEach(slot => {
        slot.classList.remove('filled', 'over');
        slot.innerHTML = `<span>${slot.dataset.slot}</span>`;
    });
    
    const fragmentElements = Array.from(fragmentsContainer.querySelectorAll('.puzzle-fragment'));
    fragmentElements.sort(() => Math.random() - 0.5);
    fragmentsContainer.innerHTML = '';
    fragmentElements.forEach(fragment => fragmentsContainer.appendChild(fragment));
    
    document.getElementById('captchaData').value = '';
}

function showMessage(text, type) {
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.innerHTML = `
        <span class="material-icons">${type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'check_circle'}</span>
        ${text}
    `;
    messageDiv.setAttribute('role', 'alert');
    messageDiv.setAttribute('aria-live', 'polite');
    
    const form = document.getElementById('loginForm');
    form.insertBefore(messageDiv, form.firstChild);
    
    if (type === 'error') {
        setTimeout(() => {
            const usernameField = document.getElementById('username');
            if (usernameField && !usernameField.disabled) {
                usernameField.focus();
            }
        }, 100);
    }
}

function acceptTerms() {
    fetch('', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'accepted_terms=1'
    }).then(response => {
        if (response.ok) {
            const modal = document.getElementById('termsModal');
            modal.style.opacity = '0';
            modal.style.transform = 'scale(0.9)';
            modal.style.transition = 'all 0.3s ease-out';
            
            setTimeout(() => {
                modal.classList.remove('active');
                modal.style.display = 'none';
                document.getElementById('username').focus();
                if (document.getElementById('captchaContainer')) {
                    initializePuzzle();
                }
            }, 300);
        }
    });
}

function declineTerms() {
    const modal = document.getElementById('termsModal');
    const acceptBtn = modal.querySelector('.btn-accept');
    const declineBtn = modal.querySelector('.btn-decline');
    
    declineBtn.innerHTML = '<span class="material-icons">refresh</span> Попробовать снова';
    acceptBtn.style.display = 'none';
    
    declineBtn.onclick = function() {
        acceptBtn.style.display = 'flex';
        declineBtn.innerHTML = '<span class="material-icons">close</span> Отказаться';
        declineBtn.onclick = declineTerms;
    };
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const modal = document.getElementById('termsModal');
        if (modal.classList.contains('active')) {
            declineTerms();
        }
    }
});

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing puzzle');
    const loginCard = document.getElementById('loginCard');
    loginCard.style.opacity = '0';
    loginCard.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        loginCard.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        loginCard.style.opacity = '1';
        loginCard.style.transform = 'translateY(0)';
    }, 100);

    setTimeout(() => {
        document.getElementById('username').focus();
    }, 500);

    if (document.getElementById('captchaContainer')) {
        initializePuzzle();
    }
});

document.getElementById('password')?.addEventListener('animationstart', function(e) {
    if (e.animationName === 'onAutoFillStart') {
        e.target.type = 'password';
    }
});